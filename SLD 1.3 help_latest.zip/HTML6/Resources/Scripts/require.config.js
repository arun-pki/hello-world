require.config({
    urlArgs: 't=636917152630354750'
});